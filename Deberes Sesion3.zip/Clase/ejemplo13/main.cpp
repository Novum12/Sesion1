#include "Persona.hpp"
#include <cstdlib>
#include <ctime>

int main(int argc, char **argv) {
    srand(time(0)); // Semilla para números aleatorios

    Persona* personas[10];
    bool edadesUsadas[28] = {false}; // índice = edad

    int edad;
    for (int i = 0; i < 10; i++) {
        do {
            edad = rand() % 10 + 18; // Edad entre 18 y 27
        } while (edadesUsadas[edad]); // Evitar edades repetidas

        edadesUsadas[edad] = true;

        personas[i] = new Persona(edad);
    }

    // Mostrar todas las personas
    for (int i = 0; i < 10; i++) {
        personas[i]->mostrar();
    }

    // Liberar memoria
    for (int i = 0; i < 10; i++) {
        delete personas[i];
    }

    return 0;
}