#include "Perasona.hpp"
#include <cstdlib>   // rand()
#include <ctime>

Persona::Persona(int edad) {
    this->edad = edad;
    this->genero = rand() % 2;
    // Generar un DNI aleatorio
    generarDNI();
}

Persona::~Persona(){}

int Persona::getEdad() {
    return this->edad;
}

// Saber si es mujer
bool Persona::esMujer() {
    return this->genero;
}

// Setter de edad
void Persona::setEdad(int edad) {
    this->edad = edad;
}

// Mostrar información completa
void Persona::mostrar() {
    cout << "Edad: " << this->edad
         << " | Genero: " << (this->genero ? "Mujer" : "Hombre")
         << " | DNI: " << this->dni
         << endl;
}

// Generar un DNI aleatorio (8 números + letra)
void Persona::generarDNI() {
    static const char letras[] = "TRWAGMYFPDXBNJZSQVHLCKE";
    int numero = rand() % 90000000 + 10000000; // Número de 8 cifras
    char letra = letras[numero % 23];

    sprintf(this->dni, "%d%c", numero, letra);
}